# Personal Expense Tracker

A full-stack expense tracking app built with Java, Spring Boot, Spring Data JPA/Hibernate, REST APIs, MySQL, React, HTML and CSS.

## Features
- Add income and expense transactions
- View transaction history
- Edit and delete transactions
- Categorize transactions
- Filter by transaction type
- Dashboard showing total income, expenses and balance

## Requirements
- Java 17+, Maven 3.8+, Node.js 18+, MySQL 8+

## Setup
1. Create database in MySQL:
   ```sql
   CREATE DATABASE expense_tracker;
   ```
2. Update `backend/src/main/resources/application.properties` with your MySQL username and password.
3. Start backend:
   ```bash
   cd backend
   mvn spring-boot:run
   ```
   API runs at `http://localhost:8080`.
4. In a second terminal, start frontend:
   ```bash
   cd frontend
   npm install
   npm run dev
   ```
   Open `http://localhost:5173`.

## REST API
- `GET /api/transactions` - list transactions
- `POST /api/transactions` - create transaction
- `PUT /api/transactions/{id}` - update transaction
- `DELETE /api/transactions/{id}` - delete transaction
- `GET /api/dashboard` - income, expenses and balance summary

## Resume description
**Personal Expense Tracker | Java, Spring Boot, React JS, MySQL, Hibernate, REST APIs**
- Developed a full-stack application to record and manage personal income and expenses.
- Implemented CRUD operations and REST APIs for transaction management.
- Integrated Spring Boot with MySQL using Spring Data JPA/Hibernate.
- Built a React dashboard to display income, expenses, balance and transaction history.

Learning/demo project: add authentication, validation, automated tests and deployment before using it with real financial data.
