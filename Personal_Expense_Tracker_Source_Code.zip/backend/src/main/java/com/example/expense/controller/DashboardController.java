package com.example.expense.controller;
import com.example.expense.model.*;
import com.example.expense.repository.TransactionRepository;
import org.springframework.web.bind.annotation.*;
import java.math.BigDecimal;
import java.util.*;
@RestController
@RequestMapping("/api/dashboard")
public class DashboardController {
 private final TransactionRepository repo;
 public DashboardController(TransactionRepository repo){this.repo=repo;}
 @GetMapping public Map<String,BigDecimal> summary(){
  BigDecimal income=BigDecimal.ZERO, expenses=BigDecimal.ZERO;
  for(Transaction t:repo.findAll()){
   if(t.getType()==TransactionType.INCOME)income=income.add(t.getAmount());
   else if(t.getType()==TransactionType.EXPENSE)expenses=expenses.add(t.getAmount());
  }
  return Map.of("income",income,"expenses",expenses,"balance",income.subtract(expenses));
 }
}
