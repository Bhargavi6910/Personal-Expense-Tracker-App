package com.example.expense.repository;
import com.example.expense.model.*;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface TransactionRepository extends JpaRepository<Transaction,Long> {
 List<Transaction> findAllByOrderByTransactionDateDescIdDesc();
 List<Transaction> findByTypeOrderByTransactionDateDesc(TransactionType type);
}
