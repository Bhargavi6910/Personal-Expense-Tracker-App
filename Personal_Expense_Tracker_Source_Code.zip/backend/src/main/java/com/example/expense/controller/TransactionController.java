package com.example.expense.controller;
import com.example.expense.model.*;
import com.example.expense.repository.TransactionRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.*;
import java.math.BigDecimal;
@RestController
@RequestMapping("/api/transactions")
public class TransactionController {
 private final TransactionRepository repo;
 public TransactionController(TransactionRepository repo){this.repo=repo;}
 @GetMapping public List<Transaction> all(@RequestParam(required=false) TransactionType type){
  return type==null?repo.findAllByOrderByTransactionDateDescIdDesc():repo.findByTypeOrderByTransactionDateDesc(type);
 }
 @PostMapping public ResponseEntity<?> create(@RequestBody Transaction t){
  String error=validate(t); if(error!=null)return ResponseEntity.badRequest().body(error);
  return ResponseEntity.ok(repo.save(t));
 }
 @PutMapping("/{id}") public ResponseEntity<?> update(@PathVariable Long id,@RequestBody Transaction input){
  Transaction t=repo.findById(id).orElse(null); if(t==null)return ResponseEntity.notFound().build();
  String error=validate(input); if(error!=null)return ResponseEntity.badRequest().body(error);
  t.setTitle(input.getTitle());t.setCategory(input.getCategory());t.setType(input.getType());
  t.setAmount(input.getAmount());t.setTransactionDate(input.getTransactionDate());t.setNote(input.getNote());
  return ResponseEntity.ok(repo.save(t));
 }
 @DeleteMapping("/{id}") public ResponseEntity<Void> delete(@PathVariable Long id){
  if(!repo.existsById(id))return ResponseEntity.notFound().build();
  repo.deleteById(id);return ResponseEntity.noContent().build();
 }
 private String validate(Transaction t){
  if(t.getTitle()==null||t.getTitle().isBlank())return "Title is required";
  if(t.getCategory()==null||t.getCategory().isBlank())return "Category is required";
  if(t.getType()==null)return "Transaction type is required";
  if(t.getAmount()==null||t.getAmount().compareTo(BigDecimal.ZERO)<=0)return "Amount must be greater than zero";
  if(t.getTransactionDate()==null)return "Date is required";
  return null;
 }
}
