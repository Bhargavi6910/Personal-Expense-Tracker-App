package com.example.expense.model;
import jakarta.persistence.*;
import java.time.LocalDate;
import java.math.BigDecimal;
@Entity
@Table(name="transactions")
public class Transaction {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 private String title;
 private String category;
 @Enumerated(EnumType.STRING) private TransactionType type;
 @Column(precision=12, scale=2) private BigDecimal amount;
 private LocalDate transactionDate;
 private String note;
 public Transaction() {}
 public Long getId(){return id;}
 public String getTitle(){return title;} public void setTitle(String v){title=v;}
 public String getCategory(){return category;} public void setCategory(String v){category=v;}
 public TransactionType getType(){return type;} public void setType(TransactionType v){type=v;}
 public BigDecimal getAmount(){return amount;} public void setAmount(BigDecimal v){amount=v;}
 public LocalDate getTransactionDate(){return transactionDate;} public void setTransactionDate(LocalDate v){transactionDate=v;}
 public String getNote(){return note;} public void setNote(String v){note=v;}
}
