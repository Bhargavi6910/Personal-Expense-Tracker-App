import React,{useEffect,useState} from 'react';
const API='http://localhost:8080/api';
const blank={title:'',category:'Food',type:'EXPENSE',amount:'',transactionDate:new Date().toISOString().slice(0,10),note:''};
async function api(path,options={}){
 const r=await fetch(API+path,{headers:{'Content-Type':'application/json'},...options});
 if(!r.ok)throw new Error(await r.text()||`Request failed: ${r.status}`);
 return r.status===204?null:r.json();
}
const money=n=>new Intl.NumberFormat('en-IN',{style:'currency',currency:'INR',maximumFractionDigits:2}).format(Number(n||0));
export default function App(){
 const [items,setItems]=useState([]),[summary,setSummary]=useState({income:0,expenses:0,balance:0});
 const [form,setForm]=useState(blank),[editing,setEditing]=useState(null),[filter,setFilter]=useState('ALL'),[error,setError]=useState('');
 async function refresh(){
  try{const [list,s]=await Promise.all([api('/transactions'),api('/dashboard')]);setItems(list);setSummary(s);setError('');}
  catch(e){setError(e.message+'. Make sure the backend and MySQL are running.');}
 }
 useEffect(()=>{refresh();},[]);
 async function submit(e){
  e.preventDefault();
  try{
   const payload={...form,amount:Number(form.amount)};
   await api(editing?`/transactions/${editing}`:'/transactions',{method:editing?'PUT':'POST',body:JSON.stringify(payload)});
   setForm(blank);setEditing(null);await refresh();
  }catch(e){setError(e.message);}
 }
 function edit(t){setEditing(t.id);setForm({...t,amount:String(t.amount),transactionDate:t.transactionDate});window.scrollTo({top:0,behavior:'smooth'});}
 async function remove(id){
  if(!confirm('Delete this transaction?'))return;
  try{await api(`/transactions/${id}`,{method:'DELETE'});await refresh();}catch(e){setError(e.message);}
 }
 const visible=filter==='ALL'?items:items.filter(x=>x.type===filter);
 return <main className="shell">
  <header className="top"><div><div className="tag">YOUR MONEY, CLEARER</div><h1>PocketPlan</h1><p>A simple place to understand where your money goes.</p></div><div className="coin">₹</div></header>
  {error&&<div className="error">{error}</div>}
  <section className="summary">
   <Metric label="Total income" value={money(summary.income)} symbol="↗" kind="income"/>
   <Metric label="Total expenses" value={money(summary.expenses)} symbol="↘" kind="expense"/>
   <Metric label="Available balance" value={money(summary.balance)} symbol="₹" kind="balance"/>
  </section>
  <section className="layout">
   <div className="card form-card"><h2>{editing?'Edit transaction':'Add a transaction'}</h2>
    <form onSubmit={submit}>
     <label>Description<input required value={form.title} placeholder="e.g. Monthly salary" onChange={e=>setForm({...form,title:e.target.value})}/></label>
     <div className="two">
      <label>Type<select value={form.type} onChange={e=>setForm({...form,type:e.target.value,category:e.target.value==='INCOME'?'Salary':'Food'})}><option value="EXPENSE">Expense</option><option value="INCOME">Income</option></select></label>
      <label>Amount (₹)<input required min="0.01" step="0.01" type="number" value={form.amount} placeholder="0.00" onChange={e=>setForm({...form,amount:e.target.value})}/></label>
     </div>
     <div className="two">
      <label>Category<select value={form.category} onChange={e=>setForm({...form,category:e.target.value})}>
       {(form.type==='INCOME'?['Salary','Freelance','Business','Investment','Other']:['Food','Travel','Shopping','Bills','Health','Education','Entertainment','Other']).map(c=><option key={c}>{c}</option>)}
      </select></label>
      <label>Date<input required type="date" value={form.transactionDate} onChange={e=>setForm({...form,transactionDate:e.target.value})}/></label>
     </div>
     <label>Note (optional)<textarea rows="2" value={form.note||''} placeholder="Add a short note..." onChange={e=>setForm({...form,note:e.target.value})}/></label>
     <div className="buttons"><button className="primary">{editing?'Save changes':'Add transaction'}</button>{editing&&<button type="button" className="muted" onClick={()=>{setEditing(null);setForm(blank);}}>Cancel</button>}</div>
    </form>
   </div>
   <div className="card history"><div className="history-head"><div><h2>Recent activity</h2><p>Your latest money movements</p></div>
    <select aria-label="Filter transactions" value={filter} onChange={e=>setFilter(e.target.value)}><option value="ALL">All</option><option value="INCOME">Income</option><option value="EXPENSE">Expenses</option></select>
   </div>
   {visible.length===0?<div className="empty">No transactions yet. Add one to get started.</div>:<div className="entries">
    {visible.map(t=><article className="entry" key={t.id}><div className={`entry-icon ${t.type.toLowerCase()}`}>{t.type==='INCOME'?'↙':'↗'}</div>
     <div className="entry-info"><strong>{t.title}</strong><span>{t.category} · {t.transactionDate}</span>{t.note&&<small>{t.note}</small>}</div>
     <div className="entry-end"><strong className={t.type==='INCOME'?'positive':'negative'}>{t.type==='INCOME'?'+':'−'}{money(t.amount)}</strong><div><button onClick={()=>edit(t)}>Edit</button><button className="delete" onClick={()=>remove(t.id)}>Delete</button></div></div>
    </article>)}
   </div>}
  </div></section>
  <footer>POCKETPLAN · PERSONAL FINANCE TRACKER</footer>
 </main>;
}
function Metric({label,value,symbol,kind}){return <div className="metric"><div className="metric-top"><span>{label}</span><i className={kind}>{symbol}</i></div><strong>{value}</strong></div>}
